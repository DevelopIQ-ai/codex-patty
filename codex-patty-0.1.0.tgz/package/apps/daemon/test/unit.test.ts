import { describe, expect, it, vi } from 'vitest';
import type { Account, PattyEvent, ProviderAdapter } from '@patty/contracts';
import { Coordinator, FakeAdapter, Router, Store, effectiveQuota, eligible, now, quotaExhausted, resetUrgency, score } from '../src/core.js';
const account = (id: string, remaining = 1): Account => ({ id, alias: id, state: 'ready', models: ['gpt-5-codex'], quota: { remaining, observedAt: now() }, health: 1, activeRuns: 0 });
const wait = () => new Promise(resolve => setTimeout(resolve, 0));
class ControlledAdapter implements ProviderAdapter {
  turnId = 'provider-turn-42'; interrupt = vi.fn(async (_id: string) => {}); private onEvent?: (event: PattyEvent) => void;
  async login() { return {}; } async cancelLogin() {} async snapshot() { return { models: ['gpt-5-codex'], quota: { observedAt: now() } }; } async createThread(_model: string) { return 'provider-thread'; }
  async run(_thread: string | undefined, _model: string, _input: string, onEvent: (event: PattyEvent) => void) { this.onEvent = onEvent; onEvent({ version: 1, type: 'delta', runId: this.turnId }); return { turnId: this.turnId }; }
  complete() { this.onEvent?.({ version: 1, type: 'completed', runId: this.turnId }); } async approve() {} async logout() {} async health() { return true; } async shutdown() {}
}
describe('state and deterministic routing', () => {
  it('stores only a derived key hash and revocation disables a key', () => { const store = new Store(); const issued = store.issueKey(); const key = issued.key; expect(store.verifyKey(key)?.id).toBe(issued.id); const row = store.db.prepare('SELECT id,hash FROM api_keys').get() as { id: string; hash: string }; expect(row.hash).not.toBe(key); expect(row.hash).toMatch(/^[a-f0-9]{64}$/); store.revokeKey(row.id); expect(store.verifyKey(key)).toBeUndefined(); });
  it('filters exact models, cooldowns, exhausted quota, and capacity', () => { const a = account('a'); expect(eligible(a, { model: 'gpt-5-codex', input: '' })).toBe(true); expect(eligible(a, { model: 'other', input: '' })).toBe(false); a.quota.remaining = 0; expect(eligible(a, { model: 'gpt-5-codex', input: '' })).toBe(false); a.quota.remaining = 1; a.cooldownUntil = '2099-01-01T00:00:00Z'; expect(eligible(a, { model: 'gpt-5-codex', input: '' })).toBe(false); });
  it('selects quota headroom deterministically and leases once', () => { const store = new Store(); const low = account('low', .1); const high = account('high', .9); store.addAccount(low); store.addAccount(high); const router = new Router(store); expect(score(high, 'seed')).toBeGreaterThan(score(low, 'seed')); const selected = router.choose({ model: 'gpt-5-codex', input: '' }, 'seed'); expect(selected.id).toBe('high'); expect(store.acquireLease('high', 'other')).toBe(false); });
  it('releases the selection lease after active-run accounting, allowing configured concurrency', async () => { const store = new Store(); const a = account('a'); store.addAccount(a); const c = new Coordinator(store, new Router(store), new Map([[a.id, new ControlledAdapter()]])); await c.start({ model: 'gpt-5-codex', input: 'one' }); await c.start({ model: 'gpt-5-codex', input: 'two' }); expect(store.account(a.id)?.activeRuns).toBe(2); expect(store.acquireLease(a.id, 'probe')).toBe(true); await expect(c.start({ model: 'gpt-5-codex', input: 'three' })).rejects.toThrow('no_eligible_account'); });
  it('honors thread pin even when another account has more quota', async () => { const store = new Store(); const first = account('first', .1); const second = account('second', .9); store.addAccount(first); store.addAccount(second); const c = new Coordinator(store, new Router(store), new Map([[first.id, new FakeAdapter()], [second.id, new FakeAdapter()]])); const thread = await c.createThread('gpt-5-codex', first.id); const run = await c.start({ model: 'gpt-5-codex', input: 'x', threadId: thread.threadId }); expect(store.run(run)?.account_id).toBe(first.id); });
  it('emits exactly one terminal event and interrupts with the provider turn ID', async () => { const store = new Store(); const a = account('a'); store.addAccount(a); const adapter = new ControlledAdapter(); const c = new Coordinator(store, new Router(store), new Map([[a.id, adapter]])); const seen: PattyEvent[] = []; const runId = await c.start({ model: 'gpt-5-codex', input: 'x' }); c.on(runId, event => seen.push(event)); await wait(); adapter.complete(); await wait(); expect(() => c.cancel(runId)).toThrow('invalid_request'); expect(seen.filter(event => ['completed', 'failed', 'cancelled'].includes(event.type))).toHaveLength(1); expect(seen.at(-1)?.type).toBe('completed');
    const second = await c.start({ model: 'gpt-5-codex', input: 'cancel' }); await wait(); c.cancel(second); expect(adapter.interrupt).toHaveBeenCalledWith('provider-turn-42'); expect(c.events(second).filter(event => event.type === 'cancelled')).toHaveLength(1); });
});

describe('persistent bootstrap state', () => {
  it('issues a bootstrap key once for an existing database', () => { const path = `/tmp/patty-${Date.now()}-${Math.random()}.sqlite`; const first = new Store(path); const key = first.issueKey().key; const second = new Store(path); expect(second.hasActiveKey()).toBe(true); expect(second.verifyKey(key)).toBeTruthy(); });
});

it('reconciles persisted in-flight work transactionally at startup', () => { const store = new Store(); const a = account('recover'); store.addAccount({ ...a, activeRuns: 1, state: 'ready' }); store.createRun({ id: 'run_recover', accountId: a.id, fingerprint: 'f', status: 'running', outputStarted: false, cancelRequested: false }); store.reconcileWorkers(); expect(store.account(a.id)?.activeRuns).toBe(0); expect(store.account(a.id)?.state).toBe('reconnect_required'); expect(store.publicRun('run_recover')?.status).toBe('cancelled'); });

it('does not publish or cool down after a provider reports completion then throws', async () => { const store=new Store(); const a=account('late'); store.addAccount(a); const adapter: ProviderAdapter={login:async()=>({}),cancelLogin:async()=>{},snapshot:async()=>({models:[],quota:{observedAt:now()}}),createThread:async(_model:string)=>'',run:async(_t,_model,_i,emit)=>{emit({version:1,type:'completed',runId:'p'});throw new Error('late');},interrupt:async()=>{},approve:async()=>{},logout:async()=>{},health:async()=>true,shutdown:async()=>{}}; const c=new Coordinator(store,new Router(store),new Map([[a.id,adapter]]));const r=await c.start({model:'gpt-5-codex',input:'x'});await new Promise(resolve=>setTimeout(resolve,0));expect(c.events(r).filter(e=>e.type==='failed')).toHaveLength(0);expect(store.account(a.id)?.cooldownUntil).toBeUndefined(); });

it('applies cooldown and health accounting for a provider failed terminal event', async () => { const store=new Store();const a=account('provider-failed');store.addAccount(a);const adapter:ProviderAdapter={login:async()=>({}),cancelLogin:async()=>{},snapshot:async()=>({models:[],quota:{observedAt:now()}}),createThread:async(_model:string)=>'',run:async(_t,_model,_i,emit)=>{emit({version:1,type:'failed',runId:'provider'});return{turnId:'provider'}},interrupt:async()=>{},approve:async()=>{},logout:async()=>{},health:async()=>true,shutdown:async()=>{}};const c=new Coordinator(store,new Router(store),new Map([[a.id,adapter]]));await c.start({model:'gpt-5-codex',input:'x'});await wait();expect(store.account(a.id)?.cooldownUntil).toBeTruthy();expect(store.account(a.id)!.health).toBeLessThan(1);});

it('enforces persisted exact capabilities', () => { const store=new Store(); const a=account('caps');store.addAccount(a);store.setCapabilities(a.id,['shell']);const router=new Router(store);expect(() => router.choose({model:'gpt-5-codex',input:'x',capabilities:['filesystem']},'caps')).toThrow('no_eligible_account');expect(router.choose({model:'gpt-5-codex',input:'x',capabilities:['shell']},'caps').id).toBe(a.id); });

it('persists normalized started and delta events for late replay', async () => { const store=new Store();const a=account('events');store.addAccount(a);const c=new Coordinator(store,new Router(store),new Map([[a.id,new FakeAdapter()]]));const run=await c.start({model:'gpt-5-codex',input:'x'});await wait();expect(c.eventItems(run).map(item=>item.event.type)).toEqual(['started','delta','usage','completed']); });
it('deletes dependent account metadata before account rollback', () => { const store=new Store();const a=account('rollback');store.addAccount(a);store.createRun({id:'r',accountId:a.id,fingerprint:'x',status:'running',outputStarted:false,cancelRequested:false});store.setCapabilities(a.id,['shell']);store.deleteAccountCascade(a.id);expect(store.account(a.id)).toBeUndefined();expect(store.run('r')).toBeUndefined(); });
it('upgrades an unversioned accounts schema before migration versions are recorded', () => { const path=`/tmp/patty-legacy-${Date.now()}.sqlite`; const {DatabaseSync}=require('node:sqlite');const db=new DatabaseSync(path);db.exec("CREATE TABLE accounts(id TEXT PRIMARY KEY,alias TEXT,state TEXT,models TEXT,quota TEXT,health REAL,active_runs INTEGER,cooldown_until TEXT); CREATE TABLE api_keys(id TEXT PRIMARY KEY,prefix TEXT,hash TEXT,revoked_at TEXT,last_used_at TEXT,created_at TEXT); CREATE TABLE runs(id TEXT PRIMARY KEY,account_id TEXT,thread_id TEXT,fingerprint TEXT,idempotency_key TEXT,status TEXT,created_at TEXT); CREATE TABLE routing_leases(account_id TEXT PRIMARY KEY,run_id TEXT,expires_at TEXT);");db.close();const upgraded=new Store(path);const columns=upgraded.db.prepare('PRAGMA table_info(accounts)').all() as {name:string}[];expect(columns.some(c=>c.name==='home_ref')).toBe(true);expect(upgraded.db.prepare('SELECT COUNT(*) AS n FROM schema_migrations').get()).toMatchObject({n:5}); });

it('fails over once before output and records an alternate attempt', async () => { const store=new Store();const first=account('first');const second=account('second');store.addAccount(first);store.addAccount(second);const failing:ProviderAdapter={login:async()=>({}),cancelLogin:async()=>{},snapshot:async()=>({models:[],quota:{observedAt:now()}}),createThread:async(_model:string)=>'',run:async()=>{throw new Error('early')},interrupt:async()=>{},approve:async()=>{},logout:async()=>{},health:async()=>true,shutdown:async()=>{}};const c=new Coordinator(store,new Router(store),new Map([[first.id,failing],[second.id,new FakeAdapter()]]));const run=await c.start({model:'gpt-5-codex',input:'x',accountId:first.id});await new Promise(resolve=>setTimeout(resolve,10));expect(store.publicRun(run)?.status).toBe('completed');expect((store.db.prepare('SELECT COUNT(*) AS n FROM run_attempts WHERE run_id=?').get(run) as {n:number}).n).toBe(2); });

it('cools a bad pre-output account, consumes alternate lease, and routes the next request cleanly', async () => { const store=new Store();const bad=account('bad');const good=account('good');store.addAccount(bad);store.addAccount(good);const badAdapter:ProviderAdapter={login:async()=>({}),cancelLogin:async()=>{},snapshot:async()=>({models:[],quota:{observedAt:now()}}),createThread:async(_model:string)=>'',run:async()=>{throw new Error('bad')},interrupt:async()=>{},approve:async()=>{},logout:async()=>{},health:async()=>true,shutdown:async()=>{}};const c=new Coordinator(store,new Router(store),new Map([[bad.id,badAdapter],[good.id,new FakeAdapter()]]));const first=await c.start({model:'gpt-5-codex',input:'one',accountId:bad.id});await new Promise(resolve=>setTimeout(resolve,15));expect(store.publicRun(first)?.status).toBe('completed');expect(store.account(bad.id)?.cooldownUntil).toBeTruthy();expect(store.account(bad.id)!.health).toBeLessThan(1);expect((store.db.prepare('SELECT COUNT(*) AS n FROM routing_leases WHERE account_id=?').get(good.id) as {n:number}).n).toBe(0);const second=await c.start({model:'gpt-5-codex',input:'two'});await new Promise(resolve=>setTimeout(resolve,10));expect(store.publicRun(second)?.accountId).toBe(good.id);expect(store.publicRun(second)?.status).toBe('completed'); });

it('never stores seeded provider output in persisted replay events', async () => { const seed='TOP_SECRET_PROVIDER_OUTPUT';const store=new Store();const a=account('redaction');store.addAccount(a);const adapter:ProviderAdapter={login:async()=>({}),cancelLogin:async()=>{},snapshot:async()=>({models:[],quota:{observedAt:now()}}),createThread:async(_model:string)=>'',run:async(_t,_model,_i,emit)=>{emit({version:1,type:'delta',runId:'p',data:{text:seed}});emit({version:1,type:'completed',runId:'p'});return{turnId:'p'}},interrupt:async()=>{},approve:async()=>{},logout:async()=>{},health:async()=>true,shutdown:async()=>{}};const c=new Coordinator(store,new Router(store),new Map([[a.id,adapter]]));const run=await c.start({model:'gpt-5-codex',input:'x'});await wait();const stored=store.db.prepare('SELECT COALESCE(group_concat(data),\'\') AS data FROM run_events WHERE run_id=?').get(run) as {data:string};expect(stored.data).not.toContain(seed);expect(c.events(run).find(event=>event.type==='delta')?.data).toEqual({redacted:true}); });

it('publishes exactly one local started event when a real adapter also emits provider started', async () => { const store = new Store(); const a = account('single-start'); store.addAccount(a); const adapter: ProviderAdapter = { login: async () => ({}), cancelLogin: async () => {}, snapshot: async () => ({ models: [], quota: { observedAt: now() } }), createThread: async (_model: string) => 'thread', run: async (_thread, _model, _input, emit) => { emit({ version: 1, type: 'started', runId: 'provider' }); emit({ version: 1, type: 'completed', runId: 'provider' }); return { turnId: 'provider' }; }, interrupt: async () => {}, approve: async () => {}, logout: async () => {}, health: async () => true, shutdown: async () => {} }; const coordinator = new Coordinator(store, new Router(store), new Map([[a.id, adapter]])); const run = await coordinator.start({ model: 'gpt-5-codex', input: 'x' }); await wait(); expect(coordinator.events(run).filter(event => event.type === 'started')).toHaveLength(1); });

it('aggregates token usage per sub and keeps only the latest snapshot for a run', async () => { const store=new Store();const first=account('metered-a');const second=account('metered-b');store.addAccount(first);store.addAccount(second);const coordinator=new Coordinator(store,new Router(store),new Map([[first.id,new FakeAdapter()],[second.id,new FakeAdapter()]]));const runs=[await coordinator.start({model:'gpt-5-codex',input:'one two three',accountId:first.id}),await coordinator.start({model:'gpt-5-codex',input:'four',accountId:second.id})];await wait();const report=store.usageReport();expect(report.totals.runs).toBe(2);expect(report.totals.totalTokens).toBe(report.accounts.reduce((sum,item)=>sum+item.totalTokens,0));expect(report.accounts.map(item=>item.alias).sort()).toEqual(['metered-a','metered-b']);expect(report.runs.map(item=>item.runId).sort()).toEqual([...runs].sort());store.recordUsage(runs[0]!,first.id,'gpt-5-codex',{inputTokens:10,cachedInputTokens:1,outputTokens:2,reasoningOutputTokens:3,totalTokens:12});const rerecorded=store.usageReport();expect(rerecorded.totals.runs).toBe(2);expect(rerecorded.runs.find(item=>item.runId===runs[0])?.totalTokens).toBe(12); });

it('reports zeroed usage totals before any run is measured', () => { const report=new Store().usageReport();expect(report).toEqual({totals:{inputTokens:0,cachedInputTokens:0,outputTokens:0,reasoningOutputTokens:0,totalTokens:0,runs:0},accounts:[],keys:[],runs:[]}); });

it('persists token counts but never output text for usage events', async () => { const store=new Store();const a=account('usage-events');store.addAccount(a);const coordinator=new Coordinator(store,new Router(store),new Map([[a.id,new FakeAdapter()]]));const run=await coordinator.start({model:'gpt-5-codex',input:'measure me'});await wait();const usage=coordinator.events(run).find(event=>event.type==='usage');expect(usage?.data).toMatchObject({inputTokens:expect.any(Number),outputTokens:expect.any(Number)});expect(JSON.stringify(usage?.data)).not.toContain('measure me'); });

describe('quota windows', () => {
  const at = Date.parse('2026-01-01T12:00:00Z');
  const windowed = (id: string, remaining: number, resetAt?: string) => ({ ...account(id, remaining), quota: { remaining, resetAt, observedAt: now() } });

  it('treats an exhausted sub as full again once its window has rolled over', () => {
    const rolledOver = windowed('past', 0, new Date(at - 1_000).toISOString());
    expect(effectiveQuota(rolledOver, at)).toBe(1);
    expect(eligible(rolledOver, { model: 'gpt-5-codex', input: 'x' }, undefined, at)).toBe(true);
    const stillBurned = windowed('future', 0, new Date(at + 3_600_000).toISOString());
    expect(effectiveQuota(stillBurned, at)).toBe(0);
    expect(eligible(stillBurned, { model: 'gpt-5-codex', input: 'x' }, undefined, at)).toBe(false);
  });

  it('reads an unknown quota as half rather than empty or full', () => expect(effectiveQuota({ ...account('unknown'), quota: { observedAt: now() } }, at)).toBe(.5));

  it('scores urgency by how close the window is to resetting', () => {
    expect(resetUrgency(windowed('none', .5), at)).toBe(0);
    expect(resetUrgency(windowed('far', .5, new Date(at + 5 * 3_600_000).toISOString()), at)).toBe(0);
    expect(resetUrgency(windowed('soon', .5, new Date(at + 3_600_000).toISOString()), at)).toBeCloseTo(.8);
    expect(resetUrgency(windowed('done', .5, new Date(at - 1).toISOString()), at)).toBe(0);
  });

  it('prefers the equally-loaded sub whose use-it-or-lose-it window resets sooner', () => {
    const soon = windowed('soon', .5, new Date(at + 30 * 60_000).toISOString());
    const later = windowed('later', .5, new Date(at + 5 * 3_600_000).toISOString());
    expect(score(soon, 'seed', at)).toBeGreaterThan(score(later, 'seed', at));
    // Reset urgency is a tiebreak, not an override: real headroom still wins.
    expect(score(windowed('roomy', 1, new Date(at + 5 * 3_600_000).toISOString()), 'seed', at)).toBeGreaterThan(score(soon, 'seed', at));
  });

  it('classifies provider limit errors as quota exhaustion, not generic failure', () => {
    for (const message of ['HTTP 429 Too Many Requests', 'rate limit reached for gpt-5-codex', 'You have hit your usage limit', 'insufficient_quota'])
      expect(quotaExhausted(new Error(message))).toBe(true);
    for (const message of ['socket hang up', 'protocol_incompatible', 'worker_missing', ''])
      expect(quotaExhausted(new Error(message))).toBe(false);
  });

  it('parks a limit-reporting sub until its own reset instead of the generic cooldown', () => {
    const store = new Store();
    const resetAt = new Date(Date.now() + 3_600_000).toISOString();
    store.addAccount({ ...account('burned', .2), quota: { remaining: .2, resetAt, observedAt: now() } });
    expect(store.exhaustQuota('burned')).toBe(resetAt);
    const stored = store.account('burned')!;
    expect(stored.quota.remaining).toBe(0);
    expect(stored.cooldownUntil).toBe(resetAt);
    expect(eligible(stored, { model: 'gpt-5-codex', input: 'x' })).toBe(false);
  });

  it('falls back to a bounded park when the provider never told us when the window resets', () => {
    const store = new Store();
    store.addAccount(account('burned', .2));
    const parked = Date.parse(store.exhaustQuota('burned')!);
    expect(parked - Date.now()).toBeGreaterThan(14 * 60_000);
    expect(parked - Date.now()).toBeLessThanOrEqual(15 * 60_000);
  });
});

describe('named keys and per-key attribution', () => {
  it('names keys, keeps the secret shown once, and revokes independently', () => {
    const store = new Store();
    const prod = store.issueKey('puffle-prod');
    const dev = store.issueKey('puffle-dev');
    expect(store.verifyKey(prod.key)).toMatchObject({ id: prod.id, name: 'puffle-prod' });
    store.revokeKey(prod.id);
    expect(store.verifyKey(prod.key)).toBeUndefined();
    expect(store.verifyKey(dev.key)).toMatchObject({ name: 'puffle-dev' });
    const listed = store.keys();
    expect(listed.map(entry => entry.name)).toEqual(['puffle-prod', 'puffle-dev']);
    expect(listed.every(entry => !JSON.stringify(entry).includes(prod.key.split('_').at(-1)!))).toBe(true);
  });

  it('attributes a run usage to the key that started it, and leaves keyless runs honest', async () => {
    const store = new Store();
    const a = account('attributed');
    store.addAccount(a);
    const coordinator = new Coordinator(store, new Router(store), new Map([[a.id, new FakeAdapter()]]));
    const prod = store.issueKey('puffle-prod');
    await coordinator.start({ model: 'gpt-5-codex', input: 'billed to prod' }, prod.id);
    await coordinator.start({ model: 'gpt-5-codex', input: 'billed to nobody' });
    await new Promise(resolve => setTimeout(resolve, 30));
    const report = store.usageReport();
    expect(report.keys).toHaveLength(2);
    expect(report.keys.find(entry => entry.keyId === prod.id)).toMatchObject({ name: 'puffle-prod', runs: 1 });
    expect(report.keys.find(entry => entry.keyId === null)).toMatchObject({ name: null, runs: 1 });
    expect(report.totals.runs).toBe(2);
    expect(report.runs.filter(run => run.keyName === 'puffle-prod')).toHaveLength(1);
  });

  it('keeps usage attributed after the key is revoked, since history should not rewrite itself', async () => {
    const store = new Store();
    const a = account('after-revoke');
    store.addAccount(a);
    const coordinator = new Coordinator(store, new Router(store), new Map([[a.id, new FakeAdapter()]]));
    const key = store.issueKey('short-lived');
    await coordinator.start({ model: 'gpt-5-codex', input: 'one run' }, key.id);
    await new Promise(resolve => setTimeout(resolve, 30));
    store.revokeKey(key.id);
    expect(store.usageReport().keys).toMatchObject([{ keyId: key.id, name: 'short-lived', runs: 1 }]);
  });
});
